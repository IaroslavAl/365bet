package org.example.test_project

const val SERVER_PORT = 8080