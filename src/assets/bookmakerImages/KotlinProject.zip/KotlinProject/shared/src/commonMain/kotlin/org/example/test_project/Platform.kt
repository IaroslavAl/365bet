package org.example.test_project

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform